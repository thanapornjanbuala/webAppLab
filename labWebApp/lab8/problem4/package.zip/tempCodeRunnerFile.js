fetch('https://api.github.com/users/thanpornjanbuala', {
  method: 'GET',
  headers: {
    'Authorization': 'Bearer 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', // Replace with your GitHub access token if needed
    'Accept': 'application/json',
  },